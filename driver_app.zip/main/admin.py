from django.contrib import admin
from main.models import *
# Register your models here.

admin.site.register(Driver)
admin.site.register(Borrower)
admin.site.register(Verhicle)
admin.site.register(BorrowerFinace)
admin.site.register(CombineVericle)
