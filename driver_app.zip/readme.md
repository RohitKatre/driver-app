Created the project using Django==2

To run the project add required details for smtp config in driver_app/settings.py and before hosting it on server
make te debug=False.

Also get the google map key for the map.